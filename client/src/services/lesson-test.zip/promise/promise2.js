var prom = new Promise(
    (resolve, reject) => {

setTimeout(() => {

    resolve('hello');
}, 2000);

    }
)


prom.then(data =>{
    console.log(data);
    console.log('world');
} );