var prom = new Promise(
    (resolve,reject) => {
     var x= 1;
     if(x<0){
        resolve('hello');
     }
     else{
        reject('error');
     }
    }
)


prom.then(data => console.log(data))
prom.catch(data => console.log(data));

console.log('gfdgfd');