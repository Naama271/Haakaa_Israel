fetch('https://jsonplaceholder.typicode.com/photos').then(
    data =>{
        data.json().then(dataJson => {
            dataJson.forEach(element => {
       console.log(element.title)
            });
        })
    }
)