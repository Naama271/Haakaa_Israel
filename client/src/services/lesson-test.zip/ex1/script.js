function check(){
    var num = document.getElementById('num').value;
    console.log(num);

    if(num.length > 1){
        document.getElementById('result').innerHTML = "מותר רק תו אחד";
    }
    if(num.length == 1){
        if(num == 'a'){
            document.getElementById('result').innerHTML = "A is good"; 
        }
        if(num == 'b'){
            document.getElementById('result').innerHTML = "b is nice"; 
        }
        else{
            document.getElementById('result').innerHTML = "GOOD DAY"; 
        }
    }
}
