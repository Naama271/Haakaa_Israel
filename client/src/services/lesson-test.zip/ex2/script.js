class Student{
    constructor(name, age, days){
        this.name = name;
        this.age = age;
        this.days = days;
    }

    getAge(){
        return this.age;
    }
    getDays(){
        return this.days;
    }
}



function createStudent(){
    var days = document.getElementById('days').value;
    var age = document.getElementById('age').value;
    var name = document.getElementById('name').value;


    var stu1 = new Student(name,age,days)
}

var yossi = new Student('yossi', 44, 5);



var student2 = new Student('shlomi', 34, 3);
console.log(yossi);
console.log(yossi.getDays());
console.log(student2.getAge());

