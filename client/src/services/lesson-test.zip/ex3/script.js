var student = [
    {name:'moshe', tel:'0505050', grade:34},
    {name:'david', tel:'33', grade:40},
    {name:'haim', tel:'333', grade:95}
];

for(var i=0; i<student.length; i++){
    if(student[i].grade > 80){
        console.log(student[i].name)
    }
}


