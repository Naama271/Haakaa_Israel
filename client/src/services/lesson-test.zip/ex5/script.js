function addToTable(){
    var fname = document.getElementById('fname').value;
    var lname = document.getElementById('lname').value;
    document.getElementById('users').innerHTML += `
    <tr>
<td> ${fname} </td> <td> ${lname} </td>
    </tr>
    
    `

}

